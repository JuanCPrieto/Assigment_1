package application;

public class UnmatchedException extends Exception {

	public UnmatchedException(String string) {
		// TODO Auto-generated constructor stub
	}

	public UnmatchedException() {
		// TODO Auto-generated constructor stub
	}

}
