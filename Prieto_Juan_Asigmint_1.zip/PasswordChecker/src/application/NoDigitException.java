package application;

public class NoDigitException extends Exception 
{

	public NoDigitException(String string) {
		// TODO Auto-generated constructor stub
	}

}
