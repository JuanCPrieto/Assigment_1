package application;

public class WeakPasswordException extends Exception {

	public WeakPasswordException(String string) {
		// TODO Auto-generated constructor stub
	}

}
