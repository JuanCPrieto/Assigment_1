package application;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class PasswordCheckerTest_STUDENT {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testIsValidPasswordTooShort() throws NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {
        try {
            assertFalse(PasswordCheckerUtility.isValidPassword("Short1")); // Too short, should throw LengthException
            PasswordCheckerUtility.isValidPassword("VeryShort"); // Should throw LengthException
        } catch (LengthException e) {
            assertEquals("The password must be at least 6 characters long", e.getMessage());
        }
    }

    @Test
    public void testIsValidPasswordNoUpperAlpha() throws LengthException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {
        try {
            PasswordCheckerUtility.isValidPassword("nouppercase1"); // No uppercase alpha, should throw NoUpperAlphaException
            assertFalse(PasswordCheckerUtility.isValidPassword("Password1")); // Valid password
        } catch (NoUpperAlphaException e) {
            assertEquals("The password must contain at least one uppercase alphabetic character", e.getMessage());
        }
    }

    @Test
    public void testIsValidPasswordNoLowerAlpha() throws LengthException, NoUpperAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {
        try {
            PasswordCheckerUtility.isValidPassword("UPPERCASE1"); // No lowercase alpha, should throw NoLowerAlphaException
            assertFalse(PasswordCheckerUtility.isValidPassword("Password1")); // Valid password
        } catch (NoLowerAlphaException e) {
            assertEquals("The password must contain at least one lowercase alphabetic character", e.getMessage());
        }
    }

    @Test
    public void testIsValidPasswordInvalidSequence() throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException {
        try {
            PasswordCheckerUtility.isValidPassword("AAAAb1"); // Invalid sequence, should throw InvalidSequenceException
            assertFalse(PasswordCheckerUtility.isValidPassword("Password1")); // Valid password
        } catch (InvalidSequenceException e) 
        {
            assertEquals("The password cannot contain more than two of the same character in sequence", e.getMessage());
        }
    }

    @Test
    public void testIsValidPasswordNoDigit() throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoSpecialCharacterException, InvalidSequenceException {
        try {
            PasswordCheckerUtility.isValidPassword("NoDigit"); // No digit, should throw NoDigitException
            assertFalse(PasswordCheckerUtility.isValidPassword("Password1")); // Valid password
        } catch (NoDigitException e) {
            assertEquals("The password must contain at least one digit", e.getMessage());
        }
    }

    @Test
    public void testIsValidPasswordSuccessful() 
    {
        try {
            assertTrue(PasswordCheckerUtility.isValidPassword("StrongP@ss1")); // Valid password
        } catch (Exception e) 
        {
            fail("Exception not expected: " + e.getMessage());
        }
    }

    @Test
    public void testInvalidPasswords() {
        ArrayList<String> passwords = new ArrayList<>();
        passwords.add("Weak2"); // Too short, should throw LengthException
        passwords.add("NoUpper2"); // No uppercase alpha, should throw NoUpperAlphaException
        passwords.add("NoLower2"); // No lowercase alpha, should throw NoLowerAlphaException
        passwords.add("InvalidSequence2"); // Invalid sequence, should throw InvalidSequenceException
        passwords.add("NoDigit"); // No digit, should throw NoDigitException
        passwords.add("StrongP@ss1"); // Valid password

        ArrayList<String> invalidPasswords = PasswordCheckerUtility.getInvalidPasswords(passwords);

        assertEquals(5, invalidPasswords.size()); // Five invalid passwords

        assertTrue(invalidPasswords.contains("Weak2 The password must be at least 6 characters long"));
        assertTrue(invalidPasswords.contains("NoUpper2 The password must contain at least one uppercase alphabetic character"));
        assertTrue(invalidPasswords.contains("NoLower2 The password must contain at least one lowercase alphabetic character"));
        assertTrue(invalidPasswords.contains("InvalidSequence2 The password cannot contain more than two of the same character in sequence"));
        assertTrue(invalidPasswords.contains("NoDigit The password must contain at least one digit"));
    }
}
